//MoreThanLimitException.java

package exceptions;

import interfaces.*;

public class MoreThanLimitException extends Exception {
	public MoreThanLimitException(String msg){
		super(msg);
		
  }
}