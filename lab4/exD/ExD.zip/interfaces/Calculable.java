//Calculable.java

package interfaces;

public interface Calculable {
	abstract double area();
 	abstract double perimeter();
}
