class Moveable{
    public: 
        virtual void forward() = 0;
        virtual void backward() = 0;
};
